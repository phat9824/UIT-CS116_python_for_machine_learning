#!/bin/bash

# Prints the message to standard output, showcasing how to display text in the terminal.
echo "This is a demonstration of executing a bash script."
